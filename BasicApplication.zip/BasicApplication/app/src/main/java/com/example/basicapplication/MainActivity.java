package com.example.basicapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText mNameEditText;
    private EditText mPasswordEditText;
    private Button Login;
    private Button Reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNameEditText=(EditText)findViewById(R.id.loginid);
        mPasswordEditText = (EditText)findViewById(R.id.Passid);
        Login=(Button)findViewById(R.id.login_button);
        Reset=(Button)findViewById(R.id.reset_button);
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(mNameEditText.getText().toString(),mPasswordEditText.getText().toString());
            }
        });
    }

    private void validate(String userName,String Password){
        if(userName.equalsIgnoreCase("Admin") && Password.equalsIgnoreCase("Admin123")){
            // Intent = move from one activity to another
             Intent intent = new Intent(MainActivity.this, SecondActivity.class);
             startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(), "Please enter valid user name ", Toast.LENGTH_LONG).show();
        }
        /*else {
            userName.setError("invalid username");
            Password.setError("invalid username");
        }*/
    }
}